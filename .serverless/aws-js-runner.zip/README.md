# express-serverless
Node Express with aws serverless lambda
