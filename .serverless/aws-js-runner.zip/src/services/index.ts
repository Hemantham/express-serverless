import BnzEncrypterService from "./bnz-encryptor.service";
export default BnzEncrypterService;
