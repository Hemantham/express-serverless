export interface BnzEncyptResponse {
  key: string;
}
