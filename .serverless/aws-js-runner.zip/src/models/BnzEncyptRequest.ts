export interface BnzEncyptRequest {
  userId: string;
  password: string;
  publicKey: string;
}
